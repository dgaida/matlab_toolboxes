function r2indicator = r2_fast(utilityPoints)
    r2indicator = sum(min(utilityPoints));