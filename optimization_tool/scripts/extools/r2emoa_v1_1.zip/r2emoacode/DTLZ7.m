function [obj, x] = DTZL7(x)
[N n] = size(x);
obj = zeros(N, 2);

g = 1 + (9/(n-1))*sum( x(:, 2:end)' )';
obj(:,1) = x(:,1);
obj(:,2) = (1+g) .* ( 2 - x(:,1)./(1+g).*(1 + sin(3*pi*x(:,1))) );