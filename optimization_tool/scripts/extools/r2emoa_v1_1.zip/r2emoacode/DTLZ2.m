function [obj, x] = DTZL2(x)
[N n] = size(x);
obj = zeros(N, 2);

x_Msquared = (x - 0.5).^2;
g = sum( x_Msquared(:, 2:end)' )';
obj(:,1) = (1+g) .* cos(x(:,1) .* pi/2);
obj(:,2) = (1+g) .* sin(x(:,1) .* pi/2);