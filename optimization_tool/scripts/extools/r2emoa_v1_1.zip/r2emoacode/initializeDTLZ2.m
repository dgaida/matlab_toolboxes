function [nVar, rngMin, rngMax, isInt, nObj, algoCall] = initializeDTLZ2()
nVar = 11;
rngMin = zeros(1,nVar);
rngMax = ones(1,nVar).* 1;
isInt = zeros(1,nVar);
nObj = 2;
algoCall = 'DTLZ2';