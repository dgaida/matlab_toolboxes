function [nVar, rngMin, rngMax, isInt, nObj, algoCall] = initializeDTLZ1()
nVar = 6;
rngMin = zeros(1,nVar);
rngMax = ones(1,nVar).* 1;
isInt = zeros(1,nVar);
nObj = 2;
algoCall = 'DTLZ1';