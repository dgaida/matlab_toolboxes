function [f,g] = G07(x),
% G07 (Hock and Schittkowski, 1981, problem 113)
% usage:  [f,g] = g07(x) ;
%
% isres('g07','min',[-10*ones(1,10);10*ones(1,10)],200,1750,30,0.45,1)
% xopt = [2.171996 2.363683 8.773926 5.095984 0.9906548 1.430574 1.321644 9.828726 8.280092 8.375927]

% Copyleft (C) 2003-2004 Thomas Philip Runarsson (e-mail: tpr@hi.is)
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
% GNU General Public License for more details.

% fitness function
f = x(:,1).^2+x(:,2).^2+x(:,1).*x(:,2)-14*x(:,1)-16*x(:,2)+(x(:,3)-10).^2+...
    4*(x(:,4)-5).^2+(x(:,5)-3).^2+2*(x(:,6)-1).^2+5*x(:,7).^2+...
    7*(x(:,8)-11).^2+2*(x(:,9)-10).^2+(x(:,10)-7).^2+45 ;

% constraints g<=0
g(:,1) = -105+4*x(:,1)+5*x(:,2)-3*x(:,7)+9*x(:,8) ;
g(:,2) = 10*x(:,1)-8*x(:,2)-17*x(:,7)+2*x(:,8) ;
g(:,3) = -8*x(:,1)+2*x(:,2)+5*x(:,9)-2*x(:,10)-12 ;
g(:,4) = 3*(x(:,1)-2).^2+4*(x(:,2)-3).^2+2*x(:,3).^2-7*x(:,4)-120 ;
g(:,5) = 5*x(:,1).^2+8*x(:,2)+(x(:,3)-6).^2-2*x(:,4)-40 ;
g(:,6) = x(:,1).^2+2*(x(:,2)-2).^2-2*x(:,1).*x(:,2)+14*x(:,5)-6*x(:,6) ;
g(:,7) = 0.5*(x(:,1)-8).^2+2*(x(:,2)-4).^2+3*x(:,5).^2-x(:,6)-30 ;
g(:,8) = -3*x(:,1)+6*x(:,2)+12*(x(:,9)-8).^2-7*x(:,10) ;
