trainMNIST;
evaMNIST;
