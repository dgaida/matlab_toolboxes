mnistdbdn.mat: trained dnn

mnistread.m: function to read the MNIST data
trainMNIST.m: sample code of training with the MNIST data
evaMNIST.m: sample code of evaluation of mnistdbdn.mat
testMNIST.m: it calls trainMNIST and evaMNIST

